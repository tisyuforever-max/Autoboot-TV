package id.sahabatquran.autostartplume;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.Color;
import android.graphics.Typeface;

public class MainActivity extends Activity {
    private TextView status;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(36, 30, 36, 30);
        root.setBackgroundColor(Color.rgb(16, 24, 39));

        TextView title = new TextView(this);
        title.setText("AUTO START PLUME");
        title.setTextColor(Color.WHITE);
        title.setTextSize(26);
        title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, matchWrap());

        TextView desc = new TextView(this);
        desc.setText("ZTE B860H V5 • Android 12\nTarget: dev.plume\n\nAplikasi ini mencoba membuka Plume 7 detik setelah TV selesai booting.");
        desc.setTextColor(Color.LTGRAY);
        desc.setTextSize(17);
        desc.setGravity(Gravity.CENTER);
        desc.setPadding(0, 22, 0, 22);
        root.addView(desc, matchWrap());

        status = new TextView(this);
        status.setTextColor(Color.WHITE);
        status.setTextSize(16);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, 10, 0, 22);
        root.addView(status, matchWrap());
        refreshStatus();

        Button test = new Button(this);
        test.setText("UJI BUKA PLUME SEKARANG");
        test.setOnClickListener(v -> {
            try {
                if (Launcher.openTarget(this)) finish();
                else Toast.makeText(this, "Aplikasi dev.plume tidak ditemukan atau tidak memiliki launcher activity", Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(this, "Gagal membuka: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
        root.addView(test, matchWrap());

        Button refresh = new Button(this);
        refresh.setText("PERIKSA APLIKASI TARGET");
        refresh.setOnClickListener(v -> refreshStatus());
        root.addView(refresh, matchWrap());

        TextView note = new TextView(this);
        note.setText("Penting: Android dapat membatasi pembukaan layar dari latar belakang. Jika otomatisasi diblokir firmware, notifikasi Plume akan menjadi alternatif jika notifikasi diizinkan.");
        note.setTextColor(Color.GRAY);
        note.setTextSize(13);
        note.setGravity(Gravity.CENTER);
        note.setPadding(0, 24, 0, 0);
        root.addView(note, matchWrap());
        setContentView(root);
    }

    private void refreshStatus() {
        boolean installed = getPackageManager().getLaunchIntentForPackage(Launcher.TARGET) != null;
        status.setText(installed ? "Status: Plume terdeteksi dan siap diuji." : "Status: dev.plume belum ditemukan.");
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }
}
