package id.sahabatquran.autostartplume;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

public class BootReceiver extends android.content.BroadcastReceiver {
    private static final String TAG = "AutoStartPlume";
    private static final long START_DELAY_MS = 7000L;

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        if (!Intent.ACTION_BOOT_COMPLETED.equals(action)
                && !Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)) return;

        final PendingResult pending = goAsync();
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            try {
                boolean launched = Launcher.openTarget(context);
                Log.i(TAG, "Boot launch attempt. launched=" + launched);
                if (!launched) Launcher.showFallbackNotification(context);
            } catch (Exception e) {
                Log.e(TAG, "Unable to open target app", e);
                Launcher.showFallbackNotification(context);
            } finally {
                pending.finish();
            }
        }, START_DELAY_MS);
    }
}
