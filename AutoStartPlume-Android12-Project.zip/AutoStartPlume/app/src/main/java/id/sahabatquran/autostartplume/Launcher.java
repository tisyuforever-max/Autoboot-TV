package id.sahabatquran.autostartplume;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

final class Launcher {
    static final String TARGET = "dev.plume";
    private static final String CHANNEL_ID = "plume_boot_fallback";

    private Launcher() {}

    static boolean openTarget(Context context) {
        PackageManager pm = context.getPackageManager();
        Intent launch = pm.getLaunchIntentForPackage(TARGET);
        if (launch == null) return false;
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        context.startActivity(launch);
        return true;
    }

    static void showFallbackNotification(Context context) {
        try {
            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Auto buka Plume", NotificationManager.IMPORTANCE_HIGH);
                channel.setDescription("Ketuk notifikasi untuk membuka Plume setelah TV menyala");
                nm.createNotificationChannel(channel);
            }
            Intent launch = context.getPackageManager().getLaunchIntentForPackage(TARGET);
            if (launch == null) return;
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            PendingIntent pi = PendingIntent.getActivity(context, 101, launch,
                    PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
            Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                    ? new Notification.Builder(context, CHANNEL_ID)
                    : new Notification.Builder(context);
            Notification notification = builder
                    .setSmallIcon(android.R.drawable.ic_media_play)
                    .setContentTitle("Plume siap dibuka")
                    .setContentText("Ketuk untuk membuka aplikasi Plume")
                    .setContentIntent(pi)
                    .setAutoCancel(true)
                    .setCategory(Notification.CATEGORY_RECOMMENDATION)
                    .build();
            nm.notify(101, notification);
        } catch (Exception ignored) { }
    }
}
