# Auto Start Plume

Helper Android app for ZTE B860H V5 / Android 12. It listens for `BOOT_COMPLETED`, waits 7 seconds, then attempts to launch the installed package `dev.plume`.

## Build with GitHub Actions
1. Create a GitHub repository and upload this project (all files/folders).
2. Open **Actions** and run **Build AutoStartPlume APK** (or push to `main`).
3. Open the completed workflow run, download artifact `AutoStartPlume-debug-apk`, and extract `app-debug.apk`.

## Install and test
```bash
adb install -r app-debug.apk
adb shell monkey -p id.sahabatquran.autostartplume 1
```
Open Auto Start Plume once, press **UJI BUKA PLUME SEKARANG**, then restart the TV to test boot behavior.

## Important Android limitation
Android 10+ restricts background activity launches. The receiver attempts a direct launch after boot; if blocked, it posts a notification as a fallback (if notifications are permitted and shown by the TV firmware). ADB/shell launch testing does not prove that the boot launch will be allowed. This APK does not root the device, replace the launcher, or change device-owner settings.
